-- control.lua

local util = require("util")

-------------------------
-- storage init and migration
-------------------------

local function migrate_colonies()
  if not storage.colonies then
    return
  end

  for _, colony in pairs(storage.colonies) do
    if colony.entity and not colony.tradepost then
      if colony.entity.valid then
        colony.tradepost = colony.entity
      end
      colony.entity = nil
    end

    if colony.tradepost and colony.tradepost.valid then
      if not colony.pos then
        colony.pos = {
          x = colony.tradepost.position.x,
          y = colony.tradepost.position.y
        }
      end
      if not colony.surface_index then
        colony.surface_index = colony.tradepost.surface.index
      end
    end

    colony.enabled = colony.enabled or {}
  end
end

local function init_storage()
  storage.players = storage.players or {}
  storage.colonies = storage.colonies or {}
  storage.next_colony_id = storage.next_colony_id or 1
  migrate_colonies()
end

local function ensure_bug_force()
  if not game.forces["bugs-trade"] then
    game.create_force("bugs-trade")
  end
  local bugs = game.forces["bugs-trade"]
  for _, f in pairs(game.forces) do
    bugs.set_cease_fire(f, true)
    f.set_cease_fire(bugs, true)
  end
end

-------------------------
-- exchange settings
-------------------------

local function get_exchange_values()
  local g = settings.global

  local choc_to_alc_input =
    (g["ftt-exchange-choc-to-alc-input"] and g["ftt-exchange-choc-to-alc-input"].value) or 10
  local choc_to_alc_output =
    (g["ftt-exchange-choc-to-alc-output"] and g["ftt-exchange-choc-to-alc-output"].value) or 100

  local alc_to_choc_input =
    (g["ftt-exchange-alc-to-choc-input"] and g["ftt-exchange-alc-to-choc-input"].value) or 10
  local alc_to_choc_output =
    (g["ftt-exchange-alc-to-choc-output"] and g["ftt-exchange-alc-to-choc-output"].value) or 100

  return {
    choc_to_alc_input = choc_to_alc_input,
    choc_to_alc_output = choc_to_alc_output,
    alc_to_choc_input = alc_to_choc_input,
    alc_to_choc_output = alc_to_choc_output
  }
end

-------------------------
-- start pack
-------------------------

local function give_start_pack(player)
  if not (player and player.valid) then
    return
  end

  storage.players[player.index] =
    storage.players[player.index] or {credits = 0}

  local inv = player.get_main_inventory()
  if inv and inv.valid then
    if inv.get_item_count("sbt-cargo-rover") == 0 then
      inv.insert({name = "sbt-cargo-rover", count = 1})
    end

    local choco = inv.get_item_count("sbt-chocolate")
    if choco < 300 then
      inv.insert({name = "sbt-chocolate", count = 300 - choco})
    end

    local alc = inv.get_item_count("sbt-alcohol")
    if alc < 200 then
      inv.insert({name = "sbt-alcohol", count = 200 - alc})
    end

    return
  end

  player.insert({name = "sbt-cargo-rover", count = 1})
  player.insert({name = "sbt-chocolate", count = 300})
  player.insert({name = "sbt-alcohol", count = 200})
end

-------------------------
-- colony helpers
-------------------------

local function make_colony_name(kind, mode)
  if mode == "exchange_choc_to_alc" then
    return {"sbt.colony_name_exchange_choc_to_alc"}
  end
  if mode == "exchange_alc_to_choc" then
    return {"sbt.colony_name_exchange_alc_to_choc"}
  end
  if kind == "metal" then
    return {"sbt.colony_name_metal"}
  end
  if kind == "components" then
    return {"sbt.colony_name_components"}
  end
  if kind == "engines" then
    return {"sbt.colony_name_engines"}
  end
  return {"sbt.colony_name_generic"}
end

local function register_colony(surface, pos, kind, currency, mode)
  if not (surface and surface.valid and pos) then
    return nil
  end

  local tradepost = surface.create_entity{
    name = "sbt-bug-tradepost",
    position = pos,
    force = "bugs-trade"
  }
  if not (tradepost and tradepost.valid) then
    return nil
  end

  local board_pos = {x = pos.x + 1, y = pos.y}
  local board = surface.create_entity{
    name = "sbt-contract-board",
    position = board_pos,
    force = "bugs-trade"
  }

  local id = storage.next_colony_id
  storage.next_colony_id = id + 1

  local name_key = make_colony_name(kind, mode)

  local colony = {
    id = id,
    pos = {
      x = tradepost.position.x,
      y = tradepost.position.y
    },
    board_pos = board and {
      x = board.position.x,
      y = board.position.y
    } or nil,
    surface_index = surface.index,
    kind = kind or "metal",
    name = name_key,
    currency = currency or "sbt-alcohol",
    mode = mode or "normal",
    tradepost = tradepost,
    board = board,
    offers = nil,
    enabled = {}
  }

  storage.colonies[id] = colony
  return colony
end

local function get_spawn_center(surface)
  if game.forces["player"] and game.forces["player"].valid then
    local sp = game.forces["player"].get_spawn_position(surface)
    return {x = sp.x, y = sp.y}
  end
  return {x = 0, y = 0}
end

local function create_start_colonies()
  if next(storage.colonies) then
    return
  end

  local surface = game.surfaces[1]
  if not surface then
    return
  end

  ensure_bug_force()

  local center = get_spawn_center(surface)
  local radius = 200
  local count = 12

  for i = 0, count - 1 do
    local angle = (2 * math.pi / count) * i
    local target = {
      center.x + math.cos(angle) * radius,
      center.y + math.sin(angle) * radius
    }
    local pos = surface.find_non_colliding_position(
      "sbt-bug-tradepost",
      target,
      24,
      1
    )

    if pos then
      local kind
      local currency
      local mode

      if i <= 3 then
        local r = i % 3
        kind = (r == 0 and "metal") or (r == 1 and "components") or "engines"
        currency = "sbt-alcohol"
        mode = "normal"
      elseif i <= 7 then
        local r = i % 3
        kind = (r == 0 and "metal") or (r == 1 and "components") or "engines"
        currency = "sbt-chocolate"
        mode = "normal"
      elseif i <= 9 then
        kind = "generic"
        currency = "sbt-chocolate"
        mode = "exchange_choc_to_alc"
      else
        kind = "generic"
        currency = "sbt-alcohol"
        mode = "exchange_alc_to_choc"
      end

      register_colony(surface, pos, kind, currency, mode)
    end
  end
end

-------------------------
-- lifecycle
-------------------------

script.on_init(function()
  init_storage()
  ensure_bug_force()
  create_start_colonies()
end)

script.on_configuration_changed(function(_)
  init_storage()
  ensure_bug_force()
  create_start_colonies()

  for _, p in pairs(game.players) do
    give_start_pack(p)
  end
end)

script.on_event(defines.events.on_player_created, function(e)
  init_storage()
  ensure_bug_force()
  create_start_colonies()
  local player = game.get_player(e.player_index)
  give_start_pack(player)
end)

-------------------------
-- dynamic spawn on chunks
-------------------------

script.on_event(defines.events.on_chunk_generated, function(e)
  local surface = e.surface
  if not (surface and surface.valid) then
    return
  end
  if surface.name ~= "nauvis" then
    return
  end
  if math.random() >= 0.003 then
    return
  end

  ensure_bug_force()

  local center = {
    x = (e.position.x + 0.5) * 32,
    y = (e.position.y + 0.5) * 32
  }
  local pos = surface.find_non_colliding_position(
    "sbt-bug-tradepost",
    center,
    16,
    1
  )
  if not pos then
    return
  end

  local r = math.random()
  local kind =
    (r < 0.33 and "metal") or
    (r < 0.66 and "components") or
    "engines"

  local mode_r = math.random()
  local mode
  local currency

  if mode_r < 0.15 then
    mode = "exchange_choc_to_alc"
    currency = "sbt-chocolate"
  elseif mode_r < 0.30 then
    mode = "exchange_alc_to_choc"
    currency = "sbt-alcohol"
  else
    mode = "normal"
    currency =
      (math.random() < 0.5) and "sbt-chocolate" or "sbt-alcohol"
  end

  register_colony(surface, pos, kind, currency, mode)
end)

-------------------------
-- random offers for normal colonies
-------------------------

local function get_item_pool_for_colony(colony)
  local kind = colony.kind or "generic"

  if kind == "metal" then
    return {
      "iron-plate", "copper-plate", "steel-plate",
      "iron-ore", "copper-ore", "stone", "coal", "stone-brick"
    }
  elseif kind == "components" then
    return {
      "iron-gear-wheel", "copper-cable", "transport-belt",
      "underground-belt", "splitter", "inserter",
      "fast-inserter", "pipe"
    }
  elseif kind == "engines" then
    return {
      "engine-unit", "electric-engine-unit",
      "pipe", "steel-plate", "iron-gear-wheel"
    }
  else
    return {
      "iron-plate", "copper-plate", "steel-plate",
      "iron-gear-wheel", "copper-cable", "transport-belt",
      "inserter", "pipe", "engine-unit", "coal",
      "stone-brick"
    }
  end
end

local function build_random_offers_for_normal_colony(colony)
  local offers = {}
  local pool = get_item_pool_for_colony(colony)
  if not pool or #pool == 0 then
    return offers
  end

  local currency = colony.currency or "sbt-alcohol"
  local count_offers = math.random(5, 20)
  local used = {}

  local function pick_unique_item()
    for _ = 1, #pool do
      local idx = math.random(1, #pool)
      local name = pool[idx]
      if not used[name] then
        used[name] = true
        return name
      end
    end
    return nil
  end

  for _ = 1, count_offers do
    local item = pick_unique_item()
    if not item then
      break
    end

    local base_amount
    local base_cost

    if item == "iron-plate" or item == "copper-plate" then
      base_amount = math.random(50, 200)
      base_cost = math.ceil(base_amount / 10)
    elseif item == "steel-plate" then
      base_amount = math.random(20, 80)
      base_cost = math.ceil(base_amount / 5)
    elseif item == "iron-gear-wheel" or item == "copper-cable" then
      base_amount = math.random(50, 200)
      base_cost = math.ceil(base_amount / 12)
    elseif item == "engine-unit" or item == "electric-engine-unit" then
      base_amount = math.random(5, 20)
      base_cost = base_amount * 4
    else
      base_amount = math.random(20, 150)
      base_cost = math.max(2, math.ceil(base_amount / 15))
    end

    table.insert(offers, {
      give = {name = item, count = base_amount},
      cost = {
        {name = currency, count = base_cost}
      }
    })
  end

  return offers
end

-------------------------
-- trade offers (all types)
-------------------------

local function get_colony_offers(colony)
  local mode = colony.mode or "normal"

  -- kantory zawsze liczone z aktualnych ustawień
  if mode == "exchange_choc_to_alc" then
    local ex = get_exchange_values()
    return {
      {
        give = {name = "sbt-alcohol", count = ex.choc_to_alc_output},
        cost = {
          {name = "sbt-chocolate", count = ex.choc_to_alc_input}
        }
      }
    }
  end

  if mode == "exchange_alc_to_choc" then
    local ex = get_exchange_values()
    return {
      {
        give = {name = "sbt-chocolate", count = ex.alc_to_choc_output},
        cost = {
          {name = "sbt-alcohol", count = ex.alc_to_choc_input}
        }
      }
    }
  end

  -- normalne kolonie dalej korzystają z cache
  if colony.offers then
    return colony.offers
  end

  colony.offers = build_random_offers_for_normal_colony(colony)
  return colony.offers
end
-------------------------
-- auto trade with checkboxes
-------------------------

local function process_colony_trade(colony)
  local ent = colony.tradepost
  if not (ent and ent.valid) then
    return
  end

  local inv = ent.get_inventory(defines.inventory.chest)
  if not (inv and inv.valid) then
    return
  end

  local offers = get_colony_offers(colony)
  if not offers or #offers == 0 then
    return
  end

  colony.enabled = colony.enabled or {}

  for i, offer in ipairs(offers) do
    if colony.enabled[i] ~= false then
      while true do
        local can_pay = true

        for _, cost in ipairs(offer.cost) do
          if inv.get_item_count(cost.name) < cost.count then
            can_pay = false
            break
          end
        end

        if not can_pay then
          break
        end

        if not inv.can_insert{
          name = offer.give.name,
          count = offer.give.count
        } then
          break
        end

        for _, cost in ipairs(offer.cost) do
          inv.remove{
            name = cost.name,
            count = cost.count
          }
        end

        inv.insert{
          name = offer.give.name,
          count = offer.give.count
        }
      end
    end
  end
end

script.on_nth_tick(60, function()
  for _, colony in pairs(storage.colonies) do
    process_colony_trade(colony)
  end
end)

-------------------------
-- colony lookup by board
-------------------------

local function is_same_pos(a, b, radius_sq)
  local dx = a.x - b.x
  local dy = a.y - b.y
  return (dx * dx + dy * dy) <= (radius_sq or 1)
end

local function find_colony_by_board(ent)
  if not (ent and ent.valid) then
    return nil
  end
  local pos = ent.position
  for _, colony in pairs(storage.colonies) do
    if colony.board and colony.board.valid and colony.board == ent then
      return colony
    end
    if colony.board_pos and is_same_pos(colony.board_pos, pos, 4) then
      return colony
    end
  end
  return nil
end

-------------------------
-- trade GUI
-------------------------

local function close_trade_gui(player)
  local root = player.gui.screen.sbt_trade_root
  if root and root.valid then
    root.destroy()
  end
end

local function open_trade_gui(player, colony)
  if not (player and player.valid and colony) then
    return
  end

  close_trade_gui(player)

  local ex = get_exchange_values()
  local offers = get_colony_offers(colony)
  local enabled = colony.enabled or {}
  colony.enabled = enabled

  local root = player.gui.screen.add{
    type = "frame",
    name = "sbt_trade_root",
    direction = "vertical",
    caption = {"sbt.trade_title", colony.name}
  }
  root.auto_center = true

  local header = root.add{
    type = "flow",
    direction = "horizontal"
  }
  header.add{
    type = "label",
    caption = {"sbt.trade_colony_label", colony.name}
  }

  if colony.mode == "exchange_choc_to_alc" then
    header.add{
      type = "label",
      caption = {
        "",
        "Wymiana: ",
        ex.choc_to_alc_input,
        " Czekolady -> ",
        ex.choc_to_alc_output,
        " Alkoholu"
      }
    }
  elseif colony.mode == "exchange_alc_to_choc" then
    header.add{
      type = "label",
      caption = {
        "",
        "Wymiana: ",
        ex.alc_to_choc_input,
        " Alkoholu -> ",
        ex.alc_to_choc_output,
        " Czekolady"
      }
    }
  else
    local currency_label =
      (colony.currency == "sbt-chocolate")
        and "Waluta: Czekolada"
        or "Waluta: Alkohol"
    header.add{
      type = "label",
      caption = currency_label
    }
  end

  local close_btn = header.add{
    type = "button",
    name = "sbt_trade_close",
    caption = "X"
  }
  close_btn.style.minimal_width = 24

  local list = root.add{
    type = "table",
    name = "sbt_trade_table",
    column_count = 3,
    draw_horizontal_lines = true
  }

  list.add{type = "label", caption = ""}
  list.add{type = "label", caption = {"sbt.trade_give"}}
  list.add{type = "label", caption = {"sbt.trade_cost"}}

  for i, offer in ipairs(offers) do
    if enabled[i] == nil then
      enabled[i] = true
    end

    local cb_name =
      "sbt_offer_toggle_" .. colony.id .. "_" .. i

    list.add{
      type = "checkbox",
      name = cb_name,
      state = enabled[i],
      caption = ""
    }

    local give = offer.give
    local give_label = list.add{
      type = "label",
      caption = {
        "",
        tostring(give.count),
        "x ",
        {"item-name." .. give.name}
      }
    }

    local cost_parts = {}
    for idx, c in ipairs(offer.cost) do
      if idx > 1 then
        table.insert(cost_parts, " + ")
      end
      table.insert(cost_parts, tostring(c.count))
      table.insert(cost_parts, "x ")
      table.insert(cost_parts, {"item-name." .. c.name})
    end

    local cost_label = list.add{
      type = "label",
      caption = cost_parts
    }

    give_label.tooltip = {
      "",
      {"sbt.trade_gives_label"},
      " ",
      {"item-name." .. give.name},
      " x",
      tostring(give.count)
    }
    cost_label.tooltip = {"sbt.trade_accepts_label"}
  end
end

-------------------------
-- open GUI on hover or PPM contract board
-------------------------

if defines.events.on_selected_entity_changed then
  script.on_event(
    defines.events.on_selected_entity_changed,
    function(e)
      local player = game.get_player(e.player_index)
      if not player then
        return
      end
      local ent = player.selected
      if ent and ent.valid and ent.name == "sbt-contract-board" then
        local colony = find_colony_by_board(ent)
        if colony then
          open_trade_gui(player, colony)
        end
      end
    end
  )
end

script.on_event(defines.events.on_gui_opened, function(e)
  if e.gui_type ~= defines.gui_type.entity then
    return
  end

  local ent = e.entity
  if not (ent and ent.valid and ent.name == "sbt-contract-board") then
    return
  end

  local player = game.get_player(e.player_index)
  if not player then
    return
  end

  local colony = find_colony_by_board(ent)
  if colony then
    open_trade_gui(player, colony)
  end
end)

-------------------------
-- checkbox handler
-------------------------

script.on_event(
  defines.events.on_gui_checked_state_changed,
  function(e)
    local element = e.element
    if not (element and element.valid) then
      return
    end

    local colony_id, offer_index =
      string.match(
        element.name,
        "^sbt_offer_toggle_(%d+)_(%d+)$"
      )
    if not (colony_id and offer_index) then
      return
    end

    colony_id = tonumber(colony_id)
    offer_index = tonumber(offer_index)

    local colony = storage.colonies[colony_id]
    if not colony then
      return
    end

    colony.enabled = colony.enabled or {}
    colony.enabled[offer_index] = element.state
  end
)

-------------------------
-- close button
-------------------------

script.on_event(defines.events.on_gui_click, function(e)
  local element = e.element
  if not (element and element.valid) then
    return
  end

  local player = game.get_player(e.player_index)
  if not player then
    return
  end

  if element.name == "sbt_trade_close" then
    close_trade_gui(player)
    return
  end
end)