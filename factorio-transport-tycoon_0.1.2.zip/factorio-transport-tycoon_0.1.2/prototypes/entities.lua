local util = require("util")

local MOD_NAME = "__factorio-transport-tycoon__"

local function icon(path)
  return MOD_NAME .. "/graphics/icons/" + path
end

-------------------------
-- rover
-------------------------

local base_car = util.table.deepcopy(data.raw["car"]["car"])
base_car.name = "sbt-cargo-rover"
base_car.icon = MOD_NAME .. "/graphics/icons/rover.png"
base_car.icon_size = 64
base_car.minable = {mining_time = 0.5, result = "sbt-cargo-rover"}
base_car.flags = {"placeable-neutral", "player-creation"}
base_car.inventory_size = 60
base_car.equipment_grid = nil
base_car.guns = {}
base_car.order = "z[sbt]-a[rover]"

-------------------------
-- bug tradepost - kantor
-------------------------

local bug_tradepost = {
  type = "container",
  name = "sbt-bug-tradepost",
  icon = MOD_NAME .. "/graphics/icons/credit.png",
  icon_size = 64,
  flags = {"placeable-neutral", "player-creation"},
  -- minable = {mining_time = 0.5, result = "stone"},
  max_health = 400,
  corpse = "small-remnants",
  collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
  inventory_size = 32,
  enable_inventory_bar = true,
  picture = {
    filename = MOD_NAME .. "/graphics/entity/bug_tradepost.png",
    width = 256,
    height = 256,
    shift = {0, 0},
    scale = 0.5
  }
}

-------------------------
-- contract board - opcjonalne
-------------------------

local contract_board = {
  type = "simple-entity",
  name = "sbt-contract-board",
  icon = MOD_NAME .. "/graphics/icons/contract_board.png",
  icon_size = 64,
  flags = {"placeable-neutral", "player-creation"},
  selectable_in_game = true,
  -- minable = {mining_time = 0.2, result = "stone"},
  max_health = 150,
  collision_box = {{-0.6, -0.3}, {0.6, 0.3}},
  selection_box = {{-0.7, -0.4}, {0.7, 0.4}},
  render_layer = "object",
  picture = {
    filename = MOD_NAME .. "/graphics/entity/contract_board.png",
    width = 256,
    height = 256,
    shift = {0, 0},
    scale = 0.35
  }
}

data:extend({
  base_car,
  bug_tradepost,
  contract_board
})
